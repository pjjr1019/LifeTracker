package com.jobsense.app.platform

import java.time.Clock
import java.time.Instant
import java.time.ZoneId

/** Device time is accessed through an injectable platform boundary. */
class PlatformClock(private val clock: Clock = Clock.systemUTC()) {
    fun now(): Instant = clock.instant()
    fun localTimezone(): ZoneId = ZoneId.systemDefault()
}
