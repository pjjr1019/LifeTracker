package com.jobsense.app.networking

data class HealthResponse(val status: String, val service: String)

/** Transport boundary. An HTTP implementation is injected when backend sync is added. */
interface HealthApi {
    suspend fun getHealth(): HealthResponse
}
