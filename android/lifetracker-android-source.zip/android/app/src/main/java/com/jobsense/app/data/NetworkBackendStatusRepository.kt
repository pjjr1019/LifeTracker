package com.jobsense.app.data

import com.jobsense.app.networking.HealthApi
import com.jobsense.domain.BackendStatus
import com.jobsense.domain.BackendStatusRepository

class NetworkBackendStatusRepository(private val api: HealthApi) : BackendStatusRepository {
    override suspend fun getStatus(): BackendStatus {
        val response = api.getHealth()
        return BackendStatus(response.service, available = response.status == "ok")
    }
}
