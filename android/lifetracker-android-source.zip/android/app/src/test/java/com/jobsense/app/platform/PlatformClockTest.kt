package com.jobsense.app.platform

import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Test

class PlatformClockTest {
    @Test fun injectedClockProvidesDeterministicTime() {
        val expected = Instant.parse("2026-10-07T12:00:00Z")
        val clock = PlatformClock(Clock.fixed(expected, ZoneOffset.UTC))
        assertEquals(expected, clock.now())
    }
}
