param(
    [Parameter(Mandatory = $true)]
    [string]$ApkPath,
    [Parameter(Mandatory = $true)]
    [string]$OutputDirectory,
    [Parameter(Mandatory = $true)]
    [long]$VersionCode,
    [Parameter(Mandatory = $true)]
    [string]$VersionName,
    [Parameter(Mandatory = $true)]
    [string]$ReleaseNotes
)

$ErrorActionPreference = "Stop"

if ($VersionCode -le 0) {
    throw "VersionCode must be positive."
}
if ([string]::IsNullOrWhiteSpace($VersionName) -or $VersionName.Length -gt 64) {
    throw "VersionName must contain 1-64 characters."
}
if ($ReleaseNotes.Length -gt 2000) {
    throw "ReleaseNotes must not exceed 2,000 characters."
}

$source = (Resolve-Path -LiteralPath $ApkPath).Path
$directory = [System.IO.Path]::GetFullPath($OutputDirectory)
$releaseDirectory = Join-Path $directory "releases\$VersionCode"
$fileName = "lifetracker-ai-$VersionCode.apk"
$apkTarget = Join-Path $releaseDirectory $fileName
$manifestTarget = Join-Path $directory "stable.json"
$manifestTemp = Join-Path $directory "stable.json.tmp"

if (Test-Path -LiteralPath $apkTarget) {
    throw "Refusing to overwrite immutable release artifact: $apkTarget"
}
if (Test-Path -LiteralPath $manifestTarget) {
    $currentManifest = Get-Content -LiteralPath $manifestTarget -Raw | ConvertFrom-Json
    if ([long]$currentManifest.versionCode -ge $VersionCode) {
        throw "The published versionCode must increase beyond $($currentManifest.versionCode)."
    }
}
if (Test-Path -LiteralPath $manifestTemp) {
    throw "A previous manifest publish is incomplete; inspect and remove $manifestTemp before retrying."
}

New-Item -ItemType Directory -Path $releaseDirectory -Force | Out-Null
Copy-Item -LiteralPath $source -Destination $apkTarget
$artifact = Get-Item -LiteralPath $apkTarget
$digest = (Get-FileHash -LiteralPath $apkTarget -Algorithm SHA256).Hash.ToLowerInvariant()

$manifest = [ordered]@{
    packageName  = "com.jobsense.feasibility"
    versionCode  = $VersionCode
    versionName  = $VersionName
    releaseNotes = $ReleaseNotes
    apkUrl       = "https://github.com/pjjr1019/LifeTracker/releases/download/v$VersionCode/$fileName"
    sha256       = $digest
    sizeBytes    = $artifact.Length
}
$json = ConvertTo-Json -InputObject $manifest -Depth 4
$encoding = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($manifestTemp, $json + [Environment]::NewLine, $encoding)
if (Test-Path -LiteralPath $manifestTarget) {
    [System.IO.File]::Replace($manifestTemp, $manifestTarget, $null)
} else {
    Move-Item -LiteralPath $manifestTemp -Destination $manifestTarget
}

Write-Output "Created release artifact and manifest in $directory"
Write-Output "Package: com.jobsense.feasibility"
Write-Output "Version: $VersionName ($VersionCode)"
Write-Output "APK SHA-256: $digest"
