package com.jobsense.feasibility

import android.graphics.Bitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Rule
import org.junit.Test
import java.io.File

class ArchiveUiDeviceTest {
    @get:Rule val compose = createComposeRule()
    private fun saveProof(name: String) {
        val folder = File(InstrumentationRegistry.getInstrumentation().targetContext.filesDir, "archive-ui-proof").apply { mkdirs() }
        File(folder, "$name.png").outputStream().use {
            val roots = compose.onAllNodes(isRoot())
            roots[roots.fetchSemanticsNodes().lastIndex].captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it)
        }
    }
    @Test fun enlargedTextKeepsThePrimaryHomeActionReachable() {
        compose.setContent {
            val density=LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density,1.5f)) {
                JobSenseTheme("light") { ArchiveShell(previewArchiveState()) }
            }
        }
        compose.onNodeWithText("Ask about work").performScrollTo().assertIsDisplayed()
        saveProof("large-text-home")
    }
    @Test fun homeAndNavigationUsePlainLanguageAndPreserveSelections() {
        compose.setContent { JobSenseTheme("light") { ArchiveShell(previewArchiveState()) } }
        compose.onNodeWithText("Open ChatGPT").assertExists()
        compose.onNodeWithText("Home").assertIsSelected()
        saveProof("light-home")
        compose.onNodeWithText("Chats", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Jordan · Supervisor").assertExists()
        saveProof("light-chats")
        compose.onNodeWithText("Settings", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Automatic Drive sharing").assertExists()
        saveProof("light-settings")
    }
    @Test fun darkHomeShowsCoverageWithoutClaimingCompleteHistory() {
        compose.setContent { JobSenseTheme("dark") { ArchiveShell(previewArchiveState()) } }
        compose.onNodeWithText("Your archive is connected").assertExists()
        compose.onNodeWithText("Everything up to date").assertDoesNotExist()
        saveProof("dark-home")
    }
    @Test fun updateSettingsShowReleaseNotesAndUseExplicitDownloadAction() {
        var downloaded = false
        val offer = AppUpdateOffer(
            3, "0.3.0", "Synthetic update notes", "https://updates.example.com/app.apk",
            "a".repeat(64), 1024
        )
        compose.setContent {
            JobSenseTheme("light") {
                ArchiveShell(
                    previewArchiveState(),
                    actions = ArchiveActions(downloadAppUpdate = { downloaded = true }),
                    updateState = AppUpdateState(
                        status = "Update available. Android approval is required after downloading.",
                        currentVersion = "0.2.0",
                        offer = offer
                    )
                )
            }
        }
        compose.onNodeWithText("Settings", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Update feed: GitHub releases. APKs must match this installed app's identity and signing certificate.").assertExists()
        compose.onNodeWithText("HTTPS update manifest URL").assertDoesNotExist()
        compose.onNodeWithText("Version 0.3.0").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Synthetic update notes").assertIsDisplayed()
        compose.onNodeWithText("Android approval is required", substring = true).assertExists()
        compose.onNodeWithText("Download").performClick()
        org.junit.Assert.assertTrue(downloaded)
    }
    @Test fun multiContactPickerAddsOnlyExplicitlyCheckedNumbers() {
        val one = HistoryScope("Synthetic supervisor", "+15551234567", "+15551234567", "US")
        val two = HistoryScope("Synthetic coworker", "+15557654321", "+15557654321", "US")
        var chosen = emptySet<String>()
        compose.setContent { JobSenseTheme("light") {
            ArchiveShell(previewArchiveState().copy(contacts = listOf(ArchiveContact(one), ArchiveContact(two))), "contacts", {},
                ArchiveActions(addContacts = { ids, _ -> chosen = ids }))
        } }
        compose.onNodeWithText("Synthetic coworker").performClick()
        compose.onNodeWithText("Add 1 chat & import history").performClick()
        org.junit.Assert.assertEquals(setOf(two.key), chosen)
    }
    @Test fun outgoingHistoryUsesYouLabelAndNewestDateFirst() {
        val base = previewArchiveState()
        val chat = base.chats.single()
        val newest = ArchiveMessage("new", chat.id, "ANDROID_SMS_STORE", "200", 1791406800000L, 1791406800000L, "OUTGOING_SENT", chat.number, "Synthetic newest reply")
        val older = newest.copy(id = "old", sourceId = "100", at = 1791320400000L, direction = "INCOMING", body = "Synthetic older instruction")
        compose.setContent { JobSenseTheme("light") { ArchiveShell(base.copy(selectedChat = chat.id, messages = listOf(newest, older))) } }
        compose.onNodeWithText("Newest messages first").assertExists()
        compose.onNodeWithText("You").assertExists()
        compose.onNodeWithText("Synthetic newest reply").assertExists()
        val newestTop = compose.onNodeWithText("Synthetic newest reply").fetchSemanticsNode().boundsInRoot.top
        val olderTop = compose.onNodeWithText("Synthetic older instruction").fetchSemanticsNode().boundsInRoot.top
        org.junit.Assert.assertTrue("Newest reply must be above older history", newestTop < olderTop)
        saveProof("newest-first-conversation")
    }
    @Test fun selectAllAndClearRespectTheVisibleContactSearch() {
        val one = HistoryScope("Synthetic supervisor", "+15551234567", "+15551234567", "US")
        val two = HistoryScope("Synthetic coworker", "+15557654321", "+15557654321", "US")
        var chosen = emptySet<String>()
        compose.setContent { JobSenseTheme("light") {
            ArchiveShell(previewArchiveState().copy(contacts = listOf(ArchiveContact(one), ArchiveContact(two))), "contacts", {},
                ArchiveActions(addContacts = { ids, _ -> chosen = ids }))
        } }
        compose.onNodeWithText("Select all", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Add 2 chats & import history").assertIsEnabled()
        org.junit.Assert.assertTrue("Selection alone must not import or share chats", chosen.isEmpty())
        saveProof("select-all-contacts")
        compose.onNodeWithText("Clear selection", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Add 0 chats & import history").assertIsNotEnabled()
        compose.onNode(hasSetTextAction()).performTextInput("coworker")
        compose.onNodeWithText("Select all shown", useUnmergedTree = true).performClick()
        compose.onNodeWithText("Add 1 chat & import history").performClick()
        org.junit.Assert.assertEquals(setOf(two.key), chosen)
    }

    @Test fun pickerDraftAndSharingChoiceSurviveRecreationWithoutImporting() {
        val one = HistoryScope("Synthetic supervisor", "+15551234567", "+15551234567", "US")
        var chosen = emptySet<String>()
        var shared = true
        val request = mutableStateOf("contacts")
        val restoration = StateRestorationTester(compose)
        restoration.setContent { JobSenseTheme("light") {
            ArchiveShell(previewArchiveState().copy(contacts = listOf(ArchiveContact(one))), request.value,
                { request.value = "" }, ArchiveActions(addContacts = { ids, sharing -> chosen = ids; shared = sharing }))
        } }
        compose.onNodeWithText("Synthetic supervisor").performClick()
        compose.onNodeWithContentDescription("Share with ChatGPT").performClick()
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithText("Add 1 chat & import history").assertIsEnabled()
        org.junit.Assert.assertTrue(chosen.isEmpty())
        compose.onNodeWithContentDescription("Share with ChatGPT").assertIsOff()
        compose.onNodeWithText("Add 1 chat & import history").performClick()
        org.junit.Assert.assertEquals(setOf(one.key), chosen)
        org.junit.Assert.assertFalse(shared)
    }

    @Test fun homeSeparatesUploadRevisionAndUnavailableAttachments() {
        val base = previewArchiveState()
        compose.setContent { JobSenseTheme("light") {
            ArchiveShell(base.copy(status = ArchiveStatus(12, 9, 100, 90, 6, 3, 1, 2)))
        } }
        compose.onNodeWithText("Saved revision").assertDoesNotExist()
        compose.onNodeWithText("Archive details").performClick()
        compose.onNodeWithText("Saved revision").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Uploaded revision").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("3 attachments waiting to upload").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("1 attachments waiting to save").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("2 attachments unavailable on this phone").performScrollTo().assertIsDisplayed()
    }

    @Test fun groupSelectAllAddsOnlyTheExplicitlyChosenGroups() {
        var chosen = emptySet<Long>()
        compose.setContent { JobSenseTheme("light") {
            ArchiveShell(previewArchiveState().copy(groups = listOf(
                ArchiveThread(501, listOf("+15551234567", "+15557654321")),
                ArchiveThread(502, listOf("+15551234567", "+15559876543")))), "groups", {},
                ArchiveActions(addGroups = { ids, _ -> chosen = ids }))
        } }
        compose.onNodeWithText("Select all", useUnmergedTree = true).performClick()
        org.junit.Assert.assertTrue(chosen.isEmpty())
        compose.onNodeWithText("Add 2 chats & import history").performClick()
        org.junit.Assert.assertEquals(setOf(501L, 502L), chosen)
    }
}
