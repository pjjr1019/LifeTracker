package com.jobsense.feasibility

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import android.net.Uri
import android.provider.Telephony

/** Read-only production verification; the SQLite engine makes a consistent private snapshot. */
class ArchiveLiveVerificationDeviceTest {
    @Test fun canonicalAddressMetadataUsesVerifiedColumns() {
        val resolver = InstrumentationRegistry.getInstrumentation().targetContext.contentResolver
        resolver.query(Uri.parse("content://mms-sms/canonical-addresses"), arrayOf("_id", "address"), null, null, null)!!.use { all ->
            check(all.moveToFirst())
            println("Address collection columns: ${all.columnNames.joinToString()}; rows: ${all.count}")
            val id = all.getLong(all.getColumnIndexOrThrow("_id"))
            val address = all.getString(all.getColumnIndexOrThrow("address"))
            resolver.query(Uri.parse("content://mms-sms/canonical-address/$id"), arrayOf("_id", "address"), null, null, null)!!.use { one ->
                check(one.moveToFirst())
                assertEquals(1, one.count)
                assertEquals(address, one.getString(one.getColumnIndexOrThrow("address")))
            }
        }
    }
    @Test fun selectedProviderReconciliationWorksOnDevice() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        try {
            ArchiveStore.reconcile(context)
            ArchiveDocuments.create(context)
            verifySavedSms(context)
        } catch (error: Exception) {
            throw AssertionError("Provider check failed: ${error.javaClass.simpleName}; " +
                error.stackTrace.filter { it.className.startsWith("com.jobsense") }.joinToString { "${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}" })
        }
    }

    @Test fun selectedSmsHistoryMatchesProviderWithoutRefreshing() {
        verifySavedSms(InstrumentationRegistry.getInstrumentation().targetContext)
    }

    private fun verifySavedSms(context: android.content.Context) {
            val db = ConversationLedger.archiveDatabase(context)
            for (chat in ArchiveStore.chats(context).filter { it.saving && it.kind == "INDIVIDUAL" }) {
                val scope = chat.individualScope()
                context.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "date", "type"), scope.querySelection, scope.selectionArgs, null)!!.use { c ->
                    while (c.moveToNext()) {
                        val providerId = c.getLong(c.getColumnIndexOrThrow("_id")).toString()
                        val at = c.getLong(c.getColumnIndexOrThrow("date"))
                        val type = c.getInt(c.getColumnIndexOrThrow("type"))
                        val direction = if (type == 1) "INCOMING" else if (type == 2) "OUTGOING_SENT" else "UNSENT_OR_OTHER"
                        db.rawQuery("SELECT direction,message_at FROM archive_messages WHERE chat_id=? AND source='ANDROID_SMS_STORE' AND source_id=?", arrayOf(chat.id, providerId)).use { saved ->
                            check(saved.moveToFirst() && saved.getString(0) == direction && saved.getLong(1) == at) { "Selected SMS history or direction missing" }
                        }
                    }
                }
                val recent = ArchiveStore.messages(context, chat.id)
                check(recent.zipWithNext().all { (a, b) -> a.at >= b.at }) { "Newest-first ordering failed" }
            }
    }

    @Test fun selectedMmsHistoryMatchesProviderWithoutRefreshing() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = ConversationLedger.archiveDatabase(context)
        val threads = ArchiveThreads.read(context)
        var checked = 0
        for (chat in ArchiveStore.chats(context).filter { it.saving }) {
            val selected = if (chat.kind == "GROUP") threads.filter { it.id == chat.threadId && it.participants.size > 1 }
                else threads.filter { it.participants.size == 1 && chat.individualScope().matchesAddress(it.participants.single()) }
            for (thread in selected) {
                context.contentResolver.query(Telephony.Mms.CONTENT_URI, arrayOf("_id", "date", "msg_box", "thread_id"),
                    "thread_id=? AND m_type IN (128,132)", arrayOf(thread.id.toString()), null)!!.use { c ->
                    while (c.moveToNext()) {
                        check(c.getLong(c.getColumnIndexOrThrow("thread_id")) == thread.id)
                        val id = c.getLong(c.getColumnIndexOrThrow("_id")).toString()
                        val at = c.getLong(c.getColumnIndexOrThrow("date")) * 1000
                        val direction = when (c.getInt(c.getColumnIndexOrThrow("msg_box"))) { 1 -> "INCOMING"; 2 -> "OUTGOING_SENT"; else -> "UNSENT_OR_OTHER" }
                        db.rawQuery("SELECT message_at,direction FROM archive_messages WHERE chat_id=? AND source='ANDROID_MMS_STORE' AND source_id=?", arrayOf(chat.id, id)).use { saved ->
                            check(saved.moveToFirst() && saved.getLong(0) == at && saved.getString(1) == direction) { "Selected MMS source or direction missing" }
                        }
                        checked++
                    }
                }
            }
        }
        println("Selected MMS source identities/directions checked: $checked")
    }
    @Test fun snapshotLiveArchiveWithoutChangingMessages() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        synchronized(ArchiveStore) {
            ArchiveStore.initialize(context)
            val db = ConversationLedger.archiveDatabase(context)
            db.rawQuery("PRAGMA integrity_check", null).use { it.moveToFirst(); assertEquals("ok", it.getString(0)) }
            val target = File(context.filesDir, "archive/development-verification.sqlite")
            target.parentFile!!.mkdirs()
            if (target.exists()) check(target.delete())
            db.execSQL("VACUUM INTO ?", arrayOf(target.absolutePath))
        }
    }
}
