package com.jobsense.feasibility

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

class AssistantSearchDeviceTest {
    @Test fun excludedChatsCannotEnterSearchResults() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val chats=ArchiveStore.chats(context)
        assertTrue(chats.isNotEmpty())
        assertTrue(AssistantSearch.search(context,"work",emptySet()).isEmpty())
        assertTrue(AssistantSearch.search(context,"work",setOf("not-a-chosen-chat")).isEmpty())
        val chosen=chats.first().id
        val results=AssistantSearch.search(context,"work job hey ladder",setOf(chosen))
        assertTrue(results.size<=6)
        assertTrue(results.all { it.chatId==chosen })
    }
}
