package com.jobsense.feasibility

import android.database.sqlite.SQLiteDatabase
import org.junit.Assert.*
import org.junit.Test
import java.io.StringWriter

/** Synthetic fixtures only: no provider writes, live selection changes, or cloud requests. */
class ArchiveDocumentConsistencyDeviceTest {
    private val chosen = ArchiveChat("chosen", "Synthetic supervisor", "INDIVIDUAL", "+15551234567",
        "+15551234567", "US", -1, emptyList(), true, true, "RCS unverified", 100, 90, 2)

    @Test fun refreshedIndexUsesUploadedLinksAndKeepsSnapshotScope() {
        val keys = listOf("segment:chosen:2026-10", "segment:unrelated:2026-10")
        val before = StringWriter()
        ArchiveDocuments.renderIndex(before, 7, listOf(chosen), keys) { "" }
        assertTrue(before.toString().contains("Full history document: Upload pending"))
        val after = StringWriter()
        ArchiveDocuments.renderIndex(after, 7, listOf(chosen), keys) { "https://drive.google.com/file/d/synthetic-${it.replace(':', '-')}/view" }
        val text = after.toString()
        assertTrue(text.contains("Archive revision: 7"))
        assertTrue(text.contains("Conversations chosen for this file: 1"))
        assertTrue(text.contains("Full history document: https://drive.google.com/file/d/synthetic-master/view"))
        assertTrue(text.contains("Month 2026-10: https://drive.google.com/file/d/synthetic-segment-chosen-2026-10/view"))
        assertFalse(text.contains("Upload pending"))
        assertFalse(text.contains("unrelated"))
    }

    @Test fun unchangedMonthlyHistoryDoesNotChangeWhenAnotherMonthArrives() {
        val before = StringWriter(); val after = StringWriter()
        ArchiveDocuments.chatHeader(before, chosen, includeFreshness = false)
        ArchiveDocuments.chatHeader(after, chosen.copy(lastCheck = 200, latestMessage = 190, messageCount = 3), includeFreshness = false)
        assertEquals(before.toString(), after.toString())
        assertTrue(before.toString().contains("RCS unverified"))
    }

    @Test fun uploadAcknowledgementLeavesNewArrivalsPendingAndCannotRegress() {
        SQLiteDatabase.create(null).use { db ->
            ArchiveSchema.create(db)
            db.execSQL("UPDATE archive_state SET revision=11 WHERE id=1")
            ArchiveStore.acknowledge(db, 7, 100)
            db.rawQuery("SELECT revision,uploaded_revision FROM archive_state", null).use { c ->
                c.moveToFirst(); assertEquals(11, c.getInt(0)); assertEquals(7, c.getInt(1))
            }
            ArchiveStore.acknowledge(db, 6, 200)
            assertThrows(IllegalArgumentException::class.java) { ArchiveStore.acknowledge(db, 12, 300) }
            db.rawQuery("SELECT uploaded_revision,uploaded_at FROM archive_state", null).use { c ->
                c.moveToFirst(); assertEquals(7, c.getInt(0)); assertEquals(100, c.getInt(1))
            }
        }
    }

    @Test fun delayedAttachmentDownloadChangesRevisionWithoutChangingItsMessage() {
        SQLiteDatabase.create(null).use { db ->
            ArchiveSchema.create(db)
            val message = ArchiveStore.putMessage(db, "chosen", "ANDROID_MMS_STORE", "42", 1000, "INCOMING", "Synthetic sender", "Photo")
            db.execSQL("INSERT INTO archive_attachments(id,message_id,name,mime,uri) VALUES('photo',?,'photo.jpg','image/jpeg','content://synthetic/42')", arrayOf(message))
            ArchiveStore.acknowledge(db, 1, 100)
            assertTrue(ArchiveStore.updateAttachmentState(db, "photo", "UNAVAILABLE"))
            assertFalse(ArchiveStore.updateAttachmentState(db, "photo", "UNAVAILABLE"))
            assertTrue(ArchiveStore.updateAttachmentState(db, "photo", "SAVED", "archive/attachments/photo", 123, "synthetic-sha"))
            assertFalse(ArchiveStore.updateAttachmentState(db, "photo", "SAVED", "archive/attachments/photo", 123, "synthetic-sha"))
            db.rawQuery("SELECT revision,uploaded_revision FROM archive_state", null).use { c ->
                c.moveToFirst(); assertEquals(3, c.getInt(0)); assertEquals(1, c.getInt(1))
            }
            db.rawQuery("SELECT state,path,bytes,sha256 FROM archive_attachments WHERE id='photo'", null).use { c ->
                c.moveToFirst(); assertEquals("SAVED", c.getString(0)); assertEquals("archive/attachments/photo", c.getString(1))
                assertEquals(123, c.getInt(2)); assertEquals("synthetic-sha", c.getString(3))
            }
            db.rawQuery("SELECT COUNT(*),MAX(message_at) FROM archive_messages", null).use { c ->
                c.moveToFirst(); assertEquals(1, c.getInt(0)); assertEquals(1000, c.getInt(1))
            }
        }
    }
}
