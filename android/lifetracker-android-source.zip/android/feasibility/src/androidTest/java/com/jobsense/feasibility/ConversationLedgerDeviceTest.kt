package com.jobsense.feasibility

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class ConversationLedgerDeviceTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var name: String
    private lateinit var helper: ConversationLedger.Database
    private val chosen = HistoryScope("Fictional contact", "+12025550199", "", "US")
    private val unrelated = HistoryScope("Different fictional contact", "+12025550198", "", "US")

    @Before fun setUp() {
        name = "jobsense-test-${UUID.randomUUID()}.db"
        helper = ConversationLedger.Database(context, name)
    }
    @After fun cleanUp() { helper.close(); context.deleteDatabase(name) }

    private fun save(scope: HistoryScope, at: Long, body: String): Boolean = ConversationLedger.insert(
        helper.writableDatabase, scope, "TEST_FIXTURE", MessageEvidenceKey.from("TEST_FIXTURE", at.toString(), body),
        at, JSONObject().put("body", body).put("direction", "INCOMING"))

    private fun exported(scope: HistoryScope): JSONObject {
        val output = ByteArrayOutputStream()
        ConversationLedger.writeEvidence(helper.readableDatabase, scope, output)
        return JSONObject(output.toString("UTF-8"))
    }

    @Test fun repeatedWordsAreSavedAndRepostsDoNotDuplicateThem() {
        assertTrue(save(chosen, 100, "hey"))
        assertTrue(save(chosen, 101, "hey"))
        assertFalse(save(chosen, 100, "hey"))
        assertEquals(2, exported(chosen).getJSONArray("evidence").length())
    }
    @Test fun selectedExportCannotIncludeAnotherConversationsRecords() {
        save(chosen, 100, "selected fixture")
        save(unrelated, 99, "unrelated fixture")
        val rows = exported(chosen).getJSONArray("evidence")
        assertEquals(1, rows.length())
        assertEquals("selected fixture", JSONObject(rows.getJSONObject(0).getString("payloadJson")).getString("body"))
    }
    @Test fun recordsSurviveReopeningTheDatabase() {
        save(chosen, 100, "persistent fixture")
        helper.close()
        helper = ConversationLedger.Database(context, name)
        assertEquals(1, exported(chosen).getJSONArray("evidence").length())
    }
    @Test fun UnicodeAndQuotesArePreservedAndMessagesAreExportedInTimeOrder() {
        val text = "Quotes \" and a newline\n🙂"
        save(chosen, 101, text)
        save(chosen, 100, "earlier")
        val rows = exported(chosen).getJSONArray("evidence")
        assertEquals(100, rows.getJSONObject(0).getLong("messageAtMillis"))
        assertEquals(text, JSONObject(rows.getJSONObject(1).getString("payloadJson")).getString("body"))
    }
    @Test fun readableDocumentPreservesTextDirectionAndExcludesUnchosenRecords() {
        val text = "Fixture quotes \" and newline\nUnicode 🙂"
        save(chosen, 100, text)
        save(unrelated, 99, "UNSELECTED_FIXTURE_MUST_NOT_APPEAR")
        ConversationLedger.insert(helper.writableDatabase, chosen, "TEST_FIXTURE",
            MessageEvidenceKey.from("TEST_FIXTURE", "sent"), 101,
            JSONObject().put("body", "sent fixture").put("direction", "OUTGOING_SENT"))
        val output = java.io.StringWriter()
        ConversationLedger.writeTranscriptEvidence(helper.readableDatabase, chosen, output)
        val document = output.toString()
        assertTrue(document.contains(JSONObject.quote(text)))
        assertTrue(document.contains("OUTGOING_SENT"))
        assertTrue(document.contains("Saved evidence records in this conversation: 2"))
        assertFalse(document.contains("UNSELECTED_FIXTURE_MUST_NOT_APPEAR"))
    }

    @Test fun shareProviderRejectsPrivateFilesOutsideChosenExportFolder() {
        val unrelatedFile = java.io.File(context.filesDir, "private-evidence-fixture.txt")
        assertThrows(IllegalArgumentException::class.java) { ChatDocument.uri(context, unrelatedFile) }
    }

}
