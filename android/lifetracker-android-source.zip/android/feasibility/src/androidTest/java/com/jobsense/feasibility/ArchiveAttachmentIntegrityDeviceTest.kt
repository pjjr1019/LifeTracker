package com.jobsense.feasibility

import android.graphics.BitmapFactory
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

/** Read only a few newest selected image files; never print or publish their contents. */
class ArchiveAttachmentIntegrityDeviceTest {
    @Test fun newestSavedImagesMatchArchiveChecksumsAndDecode() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val images = ArchiveStore.attachments(context).filter {
            it.state in listOf("SAVED", "UPLOADED") && it.mime in listOf("image/jpeg", "image/png", "image/webp")
        }.take(3)
        assertTrue("No selected saved image is available for this check", images.isNotEmpty())
        for (attachment in images) {
            val file = ArchiveStore.file(context, attachment.path)
            assertTrue(file.isFile)
            assertEquals(attachment.bytes, file.length())
            assertEquals(attachment.sha256, DriveHttp.digest(file, "SHA-256"))
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            assertTrue("Saved image cannot be decoded", bounds.outWidth > 0 && bounds.outHeight > 0)
        }
        println("Selected saved image checksums and image bounds verified: ${images.size}")
    }
}
