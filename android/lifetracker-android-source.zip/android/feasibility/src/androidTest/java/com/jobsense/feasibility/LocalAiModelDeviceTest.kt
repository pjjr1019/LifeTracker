package com.jobsense.feasibility

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

/** Uses public model weights and synthetic sources only; no personal message text enters this test. */
class LocalAiModelDeviceTest {
    @Test fun installedModelMatchesPublishedChecksumAndAnswersSyntheticAddress() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val file=LocalAiModels.file(context)
        assertTrue("Local model file has not been copied yet",file.isFile)
        assertEquals(LocalAiModels.SIZE,file.length())
        assertEquals(LocalAiModels.SHA,DriveHttp.digest(file,"SHA-256"))
        DiagnosticStore.preferences(context).edit().putString("assistantModelSha",LocalAiModels.SHA)
            .putString("assistantModelStatus","Ready · SmolLM2 360M · offline CPU").commit()
        val sources=listOf(AssistantEvidence("synthetic","synthetic-chat","Synthetic supervisor",1791451926000,
            "INCOMING","The job address is 123 Maple Avenue.","SYNTHETIC_TEST"))
        val prompt=WorkAssistantCore.prompt("What is the job address?",sources,null,"America/New_York")
        val started=android.os.SystemClock.elapsedRealtime()
        val answer=LocalAiModels.answer(context,prompt)
        val elapsed=android.os.SystemClock.elapsedRealtime()-started
        println("Synthetic-only answer: $answer")
        println("Local model synthetic inference duration ms: $elapsed; characters: ${answer.length}; citations: ${WorkAssistantCore.hasValidCitations(answer,1)}")
        assertTrue("Local model did not return a readable answer",answer.isNotBlank())
        assertTrue("Local model missed the synthetic address",answer.contains("Maple",true))
        val verified=WorkAssistantCore.verifiedExcerpt(answer,sources)
        assertNotNull("Local model did not return an exact source quotation",verified)
        assertTrue("The verified excerpt has no valid source reference",WorkAssistantCore.hasValidCitations(verified!!,1))
    }
}
