package com.jobsense.feasibility

import android.database.sqlite.SQLiteDatabase
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

class ArchiveMigrationDeviceTest {
    @Test fun upgradeRetainsOriginalEvidence() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "jobsense-archive-migration-test.db"
        context.deleteDatabase(name)
        val path = context.getDatabasePath(name)
        path.parentFile!!.mkdirs()
        SQLiteDatabase.openOrCreateDatabase(path, null).use { old ->
            old.execSQL("CREATE TABLE evidence(scope TEXT,source TEXT,evidence_key TEXT,message_at INTEGER,observed_at INTEGER,payload TEXT,PRIMARY KEY(scope,source,evidence_key))")
            old.execSQL("INSERT INTO evidence VALUES('synthetic-contact','ANDROID_SMS_STORE','original',1,2,'{\"body\":\"synthetic history\"}')")
            old.version = 1
        }
        val helper = ConversationLedger.Database(context, name)
        try {
            val db = helper.writableDatabase
            assertEquals(3, db.version)
            db.rawQuery("SELECT payload FROM evidence", null).use { assertTrue(it.moveToFirst()); assertEquals("{\"body\":\"synthetic history\"}", it.getString(0)) }
            db.rawQuery("SELECT revision FROM archive_state WHERE id=1", null).use { assertTrue(it.moveToFirst()); assertEquals(0, it.getLong(0)) }
        } finally { helper.close(); context.deleteDatabase(name) }
    }
    @Test fun sameTextFromDifferentProviderRowsIsNotMerged() {
        SQLiteDatabase.create(null).use { db ->
            ArchiveSchema.create(db)
            val one = ArchiveStore.putMessage(db, "chosen", "ANDROID_SMS_STORE", "1", 1000, "INCOMING", "+15551234567", "same text")
            val two = ArchiveStore.putMessage(db, "chosen", "ANDROID_SMS_STORE", "2", 1000, "INCOMING", "+15551234567", "same text")
            assertNotEquals(one, two)
            ArchiveStore.putMessage(db, "chosen", "ANDROID_SMS_STORE", "1", 1000, "INCOMING", "+15551234567", "same text")
            db.rawQuery("SELECT COUNT(*) FROM archive_messages", null).use { it.moveToFirst(); assertEquals(2, it.getInt(0)) }
            db.rawQuery("SELECT revision FROM archive_state", null).use { it.moveToFirst(); assertEquals(2, it.getInt(0)) }
        }
    }
    @Test fun providerStateChangesUpdateOneRecord() {
        SQLiteDatabase.create(null).use { db ->
            ArchiveSchema.create(db)
            val id = ArchiveStore.putMessage(db, "chosen", "ANDROID_SMS_STORE", "5", 1000, "UNSENT_OR_OTHER", "+15551234567", "synthetic reply")
            assertEquals(id, ArchiveStore.putMessage(db, "chosen", "ANDROID_SMS_STORE", "5", 2000, "OUTGOING_SENT", "+15551234567", "synthetic reply"))
            db.rawQuery("SELECT direction,message_at FROM archive_messages", null).use { it.moveToFirst(); assertEquals("OUTGOING_SENT", it.getString(0)); assertEquals(2000, it.getLong(1)) }
        }
    }
}
