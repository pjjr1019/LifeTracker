package com.jobsense.feasibility

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.test.platform.app.InstrumentationRegistry
import android.graphics.Bitmap
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class AssistantUiDeviceTest {
    @get:Rule val compose=createComposeRule()
    private fun saveProof(name: String) {
        val folder=File(InstrumentationRegistry.getInstrumentation().targetContext.filesDir,"archive-ui-proof").apply { mkdirs() }
        val roots=compose.onAllNodes(isRoot())
        val target=if(name.contains("confirmation")) compose.onNode(isDialog()) else roots[roots.fetchSemanticsNodes().lastIndex]
        File(folder,"$name.png").outputStream().use { output ->
            target.captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG,100,output)
        }
    }
    @Test fun assistantShowsDatedSourcesWithoutChangingSharing() {
        val base=previewArchiveState()
        val chat=base.chats.single()
        val evidence=AssistantEvidence("synthetic-source",chat.id,chat.name,1791451926000,"INCOMING","Work at 123 Maple Avenue.","ANDROID_SMS_STORE")
        var cloudChanges=0
        compose.setContent { JobSenseTheme("light") { ArchiveShell(base,actions=ArchiveActions(sharing={_,_->cloudChanges++}),
            assistantState=AssistantUiState(question="Which address?",answer="Found one matching message.",evidence=listOf(evidence))) } }
        compose.onNodeWithText("Assistant",useUnmergedTree=true).performClick()
        saveProof("light-assistant")
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("Read source message"))
        compose.onNodeWithText("Read source message").performClick()
        compose.onAllNodesWithText("Work at 123 Maple Avenue.").onLast().assertIsDisplayed()
        compose.onNodeWithText("ANDROID_SMS_STORE\nSource ID: synthetic-source").assertExists()
        assertEquals(0,cloudChanges)
    }
    @Test fun equipmentObservationRequiresReviewAndConfirmation() {
        var writes=0
        compose.setContent { JobSenseTheme("dark") { AssistantPanel(previewArchiveState(),AssistantUiState(),
            AssistantActions(equipment={_,_,_,_,_->writes++})) } }
        compose.onNodeWithText("Equipment").performClick()
        compose.onNodeWithText("Equipment name and size").performScrollTo().performTextInput("40-foot ladder")
        compose.onNodeWithText("Confirmed location").performScrollTo().performTextInput("Synthetic jobsite")
        compose.onNodeWithText("Review observation").performScrollTo().performClick()
        saveProof("dark-equipment-confirmation")
        assertEquals(0,writes)
        compose.onNodeWithText("Confirm and save").performClick()
        assertEquals(1,writes)
    }
    @Test fun plannedJobDoesNotSaveUntilConfirmed() {
        var writes=0
        compose.setContent { JobSenseTheme("light") { AssistantPanel(previewArchiveState(),AssistantUiState(),
            AssistantActions(assignment={_,address,_,_->assertEquals("123 Maple Avenue",address);writes++})) } }
        compose.onNodeWithText("Jobs").performClick()
        compose.onNodeWithText("Job address").performScrollTo().performTextInput("123 Maple Avenue")
        compose.onNodeWithText("Review planned job").performScrollTo().performClick()
        assertEquals(0,writes)
        compose.onNodeWithText("Go back").performClick()
        assertEquals(0,writes)
        compose.onNodeWithText("Review planned job").performClick()
        compose.onNodeWithText("Confirm and save").performClick()
        assertEquals(1,writes)
    }
    @Test fun suggestedJobPreservesEvidenceAndNeedsReview() {
        var writes=0
        val base=previewArchiveState();val chat=base.chats.single()
        val evidence=AssistantEvidence("synthetic-job-source",chat.id,chat.name,1791451926000,"INCOMING","Tomorrow work at 123 Maple Avenue.","SMS")
        compose.setContent { JobSenseTheme("light") { AssistantPanel(base,AssistantUiState(evidence=listOf(evidence)),
            AssistantActions(assignment={date,address,_,source ->
                assertEquals("2026-10-09",date);assertEquals("123 Maple Avenue",address);assertEquals(evidence.id,source);writes++
            })) } }
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("Review suggested job"))
        compose.onNodeWithText("Review suggested job").performClick()
        assertEquals(0,writes)
        compose.onNodeWithText("Review planned job").performScrollTo().performClick()
        assertEquals(0,writes)
        compose.onNodeWithText("Confirm and save").performClick()
        assertEquals(1,writes)
    }
    @Test fun reviewedShiftRequiresConfirmation() {
        var writes=0
        compose.setContent { JobSenseTheme("dark") { AssistantPanel(previewArchiveState(),AssistantUiState(),
            AssistantActions(shift={_,start,end,_,_,_->assertEquals("08:00",start);assertEquals("10:00",end);writes++})) } }
        compose.onNodeWithText("Work").performClick()
        compose.onNodeWithText("Start · HH:mm (24-hour)").performScrollTo().performTextInput("08:00")
        compose.onNodeWithText("End · HH:mm (24-hour)").performScrollTo().performTextInput("10:00")
        compose.onNodeWithText("Review shift").performScrollTo().performClick()
        assertEquals(0,writes)
        compose.onNodeWithText("Confirm and save").performClick()
        assertEquals(1,writes)
    }
}
