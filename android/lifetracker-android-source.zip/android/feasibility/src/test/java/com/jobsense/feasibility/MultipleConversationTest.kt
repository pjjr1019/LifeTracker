package com.jobsense.feasibility

import org.junit.Assert.*
import org.junit.Test

class MultipleConversationTest {
    private val mom = HistoryScope("Mom", "+12025550100", "", "US")
    private val coworker = HistoryScope("Coworker", "+12025550101", "", "US")
    @Test fun eitherEnabledChatCanMatchWithoutBeingTheCurrentUiSelection() {
        val identity = NotificationIdentity(listOf("Coworker"), emptyList(), emptyList(), false)
        assertEquals(listOf(coworker), TestContact.matchingConversations(listOf(mom, coworker), identity))
    }
    @Test fun anUnchosenChatCannotEnterEitherSelectedHistory() {
        val identity = NotificationIdentity(listOf("Someone else"), emptyList(), listOf("tel:+12025550102"), false)
        assertTrue(TestContact.matchingConversations(listOf(mom, coworker), identity).isEmpty())
    }
    @Test fun duplicateNamesRequireDistinctNumberEvidence() {
        val duplicateName = coworker.copy(name = "Mom")
        val ambiguous = NotificationIdentity(listOf("Mom"), emptyList(), emptyList(), false)
        assertTrue(TestContact.matchingConversations(listOf(mom, duplicateName), ambiguous).isEmpty())
        assertEquals(listOf(duplicateName), TestContact.matchingConversations(listOf(mom, duplicateName),
            ambiguous.copy(senderUris = listOf("tel:+12025550101"))))
    }
    @Test fun aChosenParticipantDoesNotAuthorizeAnUnchosenGroup() {
        val group = NotificationIdentity(listOf("Other group"), listOf("Mom"), listOf("tel:+12025550100"), true)
        assertTrue(TestContact.matchingConversations(listOf(mom, coworker), group).isEmpty())
    }
}
