package com.jobsense.feasibility

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class WirelessEndpointTest {
    @Test fun acceptsSecureSnapshotEndpoint() {
        assertEquals("https://example.com/snapshot", WirelessEndpoint.validate(" https://example.com/snapshot "))
    }
    @Test fun rejectsUnencryptedAndCredentialBearingAndRedirectLikeAddresses() {
        listOf("not a url", "http://example.com/snapshot", "https://user:secret@example.com/snapshot",
            "https://example.com/snapshot?token=secret", "https://example.com/snapshot#part",
            "https://example.com/other", "https:///snapshot", "https://example.com:0/snapshot").forEach { address ->
            assertThrows(IllegalArgumentException::class.java) { WirelessEndpoint.validate(address) }
        }
    }
}
