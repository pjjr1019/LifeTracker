package com.jobsense.feasibility

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Synthetic transport only. No account tokens, message contents, or network calls. */
class DriveUploadRecoveryTest {
    private val session = "https://www.googleapis.com/upload/drive/v3/files?upload_id=synthetic"
    private class Reply(private val code: Int, private val range: String? = null, private val failure: IOException? = null)
        : HttpURLConnection(URL("https://www.googleapis.com/")) {
        val bytes = ByteArrayOutputStream()
        var closed = false
        override fun connect() {}
        override fun disconnect() { closed = true }
        override fun usingProxy() = false
        override fun getOutputStream() = bytes
        override fun getResponseCode(): Int { failure?.let { throw it }; return code }
        override fun getHeaderField(name: String) = if (name == "Range") range else null
    }

    @Test fun interruptedUploadResumesAtServerConfirmedOffset() {
        val file = File.createTempFile("jobsense-resume-", ".bin")
        try {
            val expected = ByteArray(1024 * 1024 + 17) { (it % 251).toByte() }
            file.writeBytes(expected)
            val status = Reply(308)
            val first = Reply(308, "bytes=0-1048575")
            val interrupted = Reply(0, failure = IOException("Synthetic connection lost"))
            val initial = ArrayDeque(listOf(status, first, interrupted))
            assertThrows(IOException::class.java) {
                DriveHttp("synthetic", openConnection = { initial.removeFirst() }).resumeUpload(session, file, "application/octet-stream")
            }
            assertEquals("bytes */1048593", status.getRequestProperty("Content-Range"))
            assertArrayEquals(expected.copyOfRange(0, 1048576), first.bytes.toByteArray())

            val resumedStatus = Reply(308, "bytes=0-1048575")
            val remaining = Reply(200)
            val retry = ArrayDeque(listOf(resumedStatus, remaining))
            DriveHttp("synthetic", openConnection = { retry.removeFirst() }).resumeUpload(session, file, "application/octet-stream")
            assertEquals("bytes 1048576-1048592/1048593", remaining.getRequestProperty("Content-Range"))
            assertArrayEquals(expected.copyOfRange(1048576, expected.size), remaining.bytes.toByteArray())
            assertTrue(listOf(status, first, interrupted, resumedStatus, remaining).all { it.closed })
            assertTrue(retry.isEmpty())
        } finally { check(file.delete()) }
    }

    @Test fun alreadyCompletedSessionDoesNotSendAttachmentAgain() {
        val file = File.createTempFile("jobsense-complete-", ".txt")
        try {
            file.writeText("Synthetic attachment")
            val status = Reply(200)
            var requests = 0
            DriveHttp("synthetic", openConnection = { requests++; status }).resumeUpload(session, file, "text/plain")
            assertEquals(1, requests)
            assertEquals(0, status.bytes.size())
            assertTrue(status.closed)
        } finally { check(file.delete()) }
    }

    @Test fun invalidAcknowledgementCannotSkipUnsentBytes() {
        val file = File.createTempFile("jobsense-range-", ".txt")
        try {
            file.writeText("Synthetic attachment")
            val invalid = Reply(308, "bytes=0-9999")
            var requests = 0
            assertThrows(IllegalArgumentException::class.java) {
                DriveHttp("synthetic", openConnection = { requests++; invalid }).resumeUpload(session, file, "text/plain")
            }
            assertEquals(1, requests)
            assertTrue(invalid.closed)
        } finally { check(file.delete()) }
    }
}
