package com.jobsense.feasibility

import org.junit.Assert.*
import org.junit.Test

class HistoryScopeTest {
    @Test fun selectedUsContactMatchesItsNationalAndInternationalAddressesOnly() {
        val scope = HistoryScope("Example", "+12025550100", "(202) 555-0100", "US")
        assertTrue(scope.matchesAddress("+1 (202) 555-0100"))
        assertTrue(scope.matchesAddress("2025550100"))
        assertFalse(scope.matchesAddress("+442025550100"))
        assertFalse(scope.matchesAddress("2025550101"))
        assertEquals(scope.selectionArgs.size, scope.querySelection.count { it == '?' })
    }
    @Test fun internationalSelectionDoesNotInventNationalAliasesFromAnotherRegion() {
        val scope = HistoryScope("Example", "+442079460123", "+44 20 7946 0123", "US")
        assertTrue(scope.matchesAddress("+442079460123"))
        assertFalse(scope.matchesAddress("2079460123"))
        assertFalse(scope.matchesAddress("02079460123"))
    }
    @Test(expected = IllegalArgumentException::class) fun invalidOrInjectedNumberCannotBecomeAQuery() {
        HistoryScope("Example", "' OR 1=1 --", "", "US")
    }
    @Test(expected = IllegalArgumentException::class) fun unrelatedRawNumberCannotBroadenTheSelection() {
        HistoryScope("Example", "+12025550100", "2025550101", "US")
    }
    @Test(expected = IllegalArgumentException::class) fun zeroOnlyRawNumberCannotBecomeAnAlias() {
        HistoryScope("Example", "+12025550100", "0000000", "US")
    }
    @Test fun archiveKeyContainsNoContactNameOrPhoneNumber() {
        val first = HistoryScope("One", "+12025550100", "", "US")
        val second = HistoryScope("Renamed", "+12025550100", "", "US")
        assertEquals(first.key, second.key)
        assertEquals(64, first.key.length)
        assertFalse(first.key.contains(first.number))
    }
}
