package com.jobsense.feasibility

import org.junit.Assert.*
import org.junit.Test

class MessageEvidenceKeyTest {
    @Test fun repeatedWordsAtDifferentTimesRemainDifferentMessages() {
        assertNotEquals(MessageEvidenceKey.from("NOTIFICATION", "100", "hey"), MessageEvidenceKey.from("NOTIFICATION", "101", "hey"))
    }
    @Test fun repostingTheSameEvidenceKeepsItsKey() {
        assertEquals(MessageEvidenceKey.from("SMS", "9", "100", "hey", "1"), MessageEvidenceKey.from("SMS", "9", "100", "hey", "1"))
    }
    @Test fun delimitersInMessageBodiesDoNotMergeDifferentFields() {
        assertNotEquals(MessageEvidenceKey.from("SMS", "a:b", "c"), MessageEvidenceKey.from("SMS", "a", "b:c"))
        assertNotEquals(MessageEvidenceKey.from("SMS", "100", "hey"), MessageEvidenceKey.from("NOTIFICATION", "100", "hey"))
    }
}
