package com.jobsense.feasibility

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TestContactTest {
    @Test fun matchingInternationalNumbersAreAllowed() {
        assertTrue(TestContact.matchesNumber("+1 (202) 555-0100", "+12025550100"))
    }
    @Test fun unrelatedAndAmbiguousNumbersAreRejected() {
        assertFalse(TestContact.matchesNumber("+12025550100", "+442025550100"))
        assertFalse(TestContact.matchesNumber("+12025550100", "2025550100"))
        assertFalse(TestContact.matchesNumber("", "+12025550100"))
    }

    @Test fun conversationMetadataMatchesWhenCollapsedTitleIsGeneric() {
        val identity = NotificationIdentity(listOf("Google Messages", "Mom"), emptyList(), emptyList(), false)
        assertTrue(TestContact.matchesNotification("Mom", "+12025550100", identity))
        assertFalse(TestContact.matchesNotification("Dad", "+12025550100", identity))
    }

    @Test fun senderNameAloneDoesNotAuthorizeAnUnselectedGroup() {
        val group = NotificationIdentity(listOf("Other group"), listOf("Mom"), emptyList(), true)
        assertFalse(TestContact.matchesNotification("Mom", "+12025550100", group))
        assertTrue(TestContact.matchesNotification("Mom", "+12025550100", group.copy(isGroupConversation = false)))
    }

    @Test fun unknownIdentityDoesNotMatchAnEmptyOrDifferentSelection() {
        val identity = NotificationIdentity(listOf("Other"), listOf("Other"), listOf("tel:+442025550100"), false)
        assertFalse(TestContact.matchesNotification("", "", identity))
        assertFalse(TestContact.matchesNotification("Mom", "+12025550100", identity))
        assertTrue(TestContact.matchesNotification("Mom", "+12025550100", identity.copy(senderUris = listOf("tel:+12025550100"))))
    }
    @Test fun selectedInternationalNumberCanBeTheDirectConversationTitle() {
        val identity = NotificationIdentity(listOf("+1 (202) 555-0100"), emptyList(), emptyList(), false)
        assertTrue(TestContact.matchesNotification("Mom", "+12025550100", identity))
        assertFalse(TestContact.matchesNotification("Mom", "+12025550101", identity))
    }
    @Test fun selectedParticipantUriDoesNotAuthorizeAnUnselectedGroup() {
        val identity = NotificationIdentity(listOf("Unselected group"), emptyList(), listOf("tel:+12025550100"), true)
        assertFalse(TestContact.matchesNotification("Mom", "+12025550100", identity))
    }
}
