package com.jobsense.feasibility

import java.net.URI
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class AppUpdateRulesTest {
    @Test
    fun acceptsHttpsManifestAndSameHostApk() {
        val manifest = AppUpdateRules.validateManifestUrl(" https://updates.example.com/android/stable.json ")
        assertEquals(
            URI("https://updates.example.com/android/app.apk"),
            AppUpdateRules.validateArtifactUrl(manifest, "app.apk")
        )
    }

    @Test
    fun defaultManifestUsesTheLifeTrackerRawGithubFeed() {
        assertEquals(
            URI("https://raw.githubusercontent.com/pjjr1019/LifeTracker/main/android/updates/stable.json"),
            AppUpdateRules.validateManifestUrl(AppUpdates.DEFAULT_MANIFEST_URL)
        )
    }

    @Test
    fun rejectsUnsafeManifestUrls() {
        listOf(
            "http://updates.example.com/stable.json",
            "https://user:password@updates.example.com/stable.json",
            "https://updates.example.com/stable.json?token=secret",
            "https://updates.example.com/stable.json#latest",
            "https://updates.example.com:0/stable.json",
            "not a URL"
        ).forEach { value ->
            assertThrows(IllegalArgumentException::class.java) {
                AppUpdateRules.validateManifestUrl(value)
            }
        }
    }

    @Test
    fun rejectsCrossHostOrInsecureApks() {
        val manifest = URI("https://updates.example.com/stable.json")
        listOf(
            "http://updates.example.com/app.apk",
            "https://downloads.example.com/app.apk",
            "https://updates.example.com/app.apk?token=secret",
            "https://updates.example.com/app.zip"
        ).forEach { value ->
            assertThrows(IllegalArgumentException::class.java) {
                AppUpdateRules.validateArtifactUrl(manifest, value)
            }
        }
    }

    @Test
    fun acceptsOnlyTheOfficialLifeTrackerGithubReleaseAsAnExternalArtifact() {
        val manifest = URI(AppUpdates.DEFAULT_MANIFEST_URL)
        assertEquals(
            URI("https://github.com/pjjr1019/LifeTracker/releases/download/v4/lifetracker-ai-4.apk"),
            AppUpdateRules.validateArtifactUrl(
                manifest,
                "https://github.com/pjjr1019/LifeTracker/releases/download/v4/lifetracker-ai-4.apk"
            )
        )
        listOf(
            "https://github.com/other/LifeTracker/releases/download/v4/lifetracker-ai-4.apk",
            "https://github.com/pjjr1019/LifeTracker/releases/download/v4/update.apk",
            "https://github.com/pjjr1019/LifeTracker/archive/refs/heads/main.zip",
            "https://updates.example.com.attacker.invalid/lifetracker-ai-4.apk"
        ).forEach { value ->
            assertThrows(IllegalArgumentException::class.java) {
                AppUpdateRules.validateArtifactUrl(manifest, value)
            }
        }
    }

    @Test
    fun validatesGithubReleaseRedirectHosts() {
        listOf(
            URI("https://github.com/pjjr1019/LifeTracker/releases/download/v4/app.apk"),
            URI("https://release-assets.githubusercontent.com/file"),
            URI("https://objects.githubusercontent.com/file")
        ).forEach(AppUpdateRules::validateDownloadUrl)
        listOf(
            URI("http://github.com/pjjr1019/LifeTracker/releases/download/v4/app.apk"),
            URI("https://attacker.example/file"),
            URI("https://github.com@attacker.example/file"),
            URI("https://github.com/file#fragment")
        ).forEach { uri ->
            assertThrows(IllegalArgumentException::class.java) {
                AppUpdateRules.validateDownloadUrl(uri)
            }
        }
    }

    @Test
    fun rejectsDowngradesInvalidHashesAndOversizedArtifacts() {
        assertThrows(IllegalArgumentException::class.java) {
            AppUpdateRules.validateOffer(2, "2.0", "", "a".repeat(64), 1, 2)
        }
        assertThrows(IllegalArgumentException::class.java) {
            AppUpdateRules.validateOffer(3, "3.0", "", "bad", 1, 2)
        }
        assertThrows(IllegalArgumentException::class.java) {
            AppUpdateRules.validateOffer(
                3, "3.0", "", "a".repeat(64), AppUpdateRules.MAX_APK_BYTES + 1, 2
            )
        }
    }
}
