package com.jobsense.feasibility

import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test
import java.io.File

class DriveArchiveSecurityTest {
    @Test fun onlyGoogleHttpsUploadLocationsAreAccepted() {
        DriveHttp.validateUrl("https://www.googleapis.com/upload/drive/v3/files?upload_id=synthetic")
        listOf("http://www.googleapis.com/upload", "https://attacker.example/upload", "https://www.googleapis.com.attacker.example/upload",
            "https://user:password@www.googleapis.com/upload", "https://www.googleapis.com:444/upload", "https://www.googleapis.com/upload#fragment").forEach {
            try { DriveHttp.validateUrl(it); fail("Unsafe upload location accepted") } catch (_: IllegalArgumentException) { }
        }
    }
    @Test fun streamedChecksumsMatchUploadedBytes() {
        val file = File.createTempFile("jobsense-checksum-", ".txt")
        try {
            file.writeText("hello", Charsets.UTF_8)
            assertEquals("5d41402abc4b2a76b9719d911017c592", DriveHttp.digest(file, "MD5"))
            assertEquals("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824", DriveHttp.digest(file, "SHA-256"))
        } finally { check(file.delete()) }
    }
}
