package com.jobsense.domain

enum class AppEnvironment(val wireValue: String) {
    DEVELOPMENT("development"), TEST("test"), PRODUCTION("production");

    companion object {
        fun parse(value: String): AppEnvironment = entries.firstOrNull { it.wireValue == value }
            ?: throw IllegalArgumentException("Unsupported environment: $value")
    }
}

data class BackendStatus(val service: String, val available: Boolean) {
    init {
        require(service.isNotBlank()) { "Service name is required" }
    }
}

interface BackendStatusRepository {
    suspend fun getStatus(): BackendStatus
}
