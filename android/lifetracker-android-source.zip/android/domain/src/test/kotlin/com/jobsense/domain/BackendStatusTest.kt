package com.jobsense.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class BackendStatusTest {
    @Test fun supportedEnvironmentIsParsed() {
        assertEquals(AppEnvironment.TEST, AppEnvironment.parse("test"))
        assertEquals(AppEnvironment.PRODUCTION, AppEnvironment.parse("production"))
    }

    @Test(expected = IllegalArgumentException::class)
    fun unknownEnvironmentIsRejected() {
        AppEnvironment.parse("prodution")
    }

    @Test(expected = IllegalArgumentException::class)
    fun emptyServiceIsRejected() {
        BackendStatus(" ", available = true)
    }
}
